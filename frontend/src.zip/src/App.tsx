import AppRoutes from "./app/AppRoutes";

export default function App() {
  return <AppRoutes />;
}